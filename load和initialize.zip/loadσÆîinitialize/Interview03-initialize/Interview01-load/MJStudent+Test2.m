//
//  MJStudent+Test2.m
//  Interview01-load
//
//  Created by MJ Lee on 2018/5/5.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJStudent+Test2.h"

@implementation MJStudent (Test2)
+ (void)initialize
{
    NSLog(@"MJStudent (Test2) +initialize");
}
@end
