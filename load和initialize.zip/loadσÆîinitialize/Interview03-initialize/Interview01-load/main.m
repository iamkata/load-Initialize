//
//  main.m
//  Interview01-load
//
//  Created by MJ Lee on 2018/5/5.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"
#import "MJStudent.h"
#import "MJTeacher.h"
#import <objc/runtime.h>

void printMethodNamesOfClass(Class cls)
{
    unsigned int count;
    // 获得方法数组
    Method *methodList = class_copyMethodList(cls, &count);
    
    // 存储方法名
    NSMutableString *methodNames = [NSMutableString string];
    
    // 遍历所有的方法
    for (int i = 0; i < count; i++) {
        // 获得方法
        Method method = methodList[i];
        // 获得方法名
        NSString *methodName = NSStringFromSelector(method_getName(method));
        // 拼接方法名
        [methodNames appendString:methodName];
        [methodNames appendString:@", "];
    }
    
    // 释放
    free(methodList);
    
    // 打印方法名
    NSLog(@"%@ %@", cls, methodNames);
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        BOOL sutdentInitialized = NO; //student是否初始化
//        BOOL personInitialized = NO;  //person是否初始化
//        BOOL teacherInitialized = NO; //teacher是否初始化
        
        
        [MJStudent alloc];
        [MJStudent alloc];
        [MJStudent alloc];
        [MJTeacher alloc];
        //如果MJStudent实现了+initialize方法,打印结果为
        /*
         2019-04-12 16:36:35.390622+0800 Interview01-load[20315:4641309] MJPerson (Test2) +initialize
         2019-04-12 16:36:35.390800+0800 Interview01-load[20315:4641309] MJStudent (Test2) +initialize
         */
        //如果MJStudent没有实现了+initialize方法,打印结果为
        /*
         2019-04-12 16:36:35.390622+0800 Interview01-load[20315:4641309] MJPerson (Test2) +initialize
         2019-04-12 16:36:35.390800+0800 Interview01-load[20315:4641309] MJPerson (Test2) +initialize
         */
        //原因:+initialize是消息发送
        //①.如果子类没有实现+initialize，会调用父类的+initialize（所以父类的+initialize可能会被调用多次）
        //②.如果分类实现了+initialize，就覆盖类本身的+initialize调用
        
        
        //[MJStudent alloc]的发送信息伪代码
//        if (!sutdentInitialized) { ->自己
//            if (!personInitialized) { ->父类
//                objc_msgSend([MJPerson class], @selector(initialize));
//                personInitialized = YES;
//            }
//
//            objc_msgSend([MJStudent class], @selector(initialize));
//            sutdentInitialized = YES;
//        }
        
//        if (自己没有初始化) {
//            if (父类没有初始化) {
//                objc_msgSend([父类 class], @selector(initialize));
//                personInitialized = YES;
//            }
//            objc_msgSend([自己 class], @selector(initialize));
//            sutdentInitialized = YES;
//        }
        
        
        /*
         [MJStudent alloc];
         [MJTeacher alloc];
         //执行上面两行代码后,内部执行的其实是下面的代码
         
         objc_msgSend([MJPerson class], @selector(initialize));
         objc_msgSend([MJStudent class], @selector(initialize));
         objc_msgSend([MJTeacher class], @selector(initialize));
         //所以打印结果是
         2019-04-12 16:36:35.390622+0800 Interview01-load[20315:4641309] MJPerson (Test2) +initialize
         2019-04-12 16:36:35.390800+0800 Interview01-load[20315:4641309] MJStudent (Test2) +initialize
         2019-04-12 16:36:35.390622+0800 Interview01-load[20315:4641309] MJTeacher (Test2) +initialize
         */
        
        //方法调用流程
//        [MJPerson alloc];
//        isa -> 类对象\元类对象，寻找方法，调用
//        superclass -> 类对象\元类对象，寻找方法，调用
//        superclass -> 类对象\元类对象，寻找方法，调用
//        superclass -> 类对象\元类对象，寻找方法，调用
//        superclass -> 类对象\元类对象，寻找方法，调用
//        objc_msgSend([MJPerson class], @selector(alloc));
        
        
//        [MJPerson alloc];
//        [MJPerson alloc];
//        [MJStudent alloc];
//        [MJStudent alloc];
        
#pragma mark - 总结
        /*
         1.+initialize方法会在类第一次接收到消息时调用
         
         2.调用顺序
         先调用父类的+initialize，再调用子类的+initialize(因为要先初始化父类，再初始化子类，而且每个类只会初始化1次)
         */
        
        /*
         +initialize和+load的很大区别是，+initialize是通过objc_msgSend进行调用的，所以有以下特点
         ①.如果子类没有实现+initialize，会调用父类的+initialize（所以父类的+initialize可能会被调用多次）
         ②.如果分类实现了+initialize，就覆盖类本身的+initialize调用
         */
        
        
        //+load和+initialize区别
        
        /*
         load、initialize方法的区别什么？
         1.调用方式
         1> load是根据函数地址直接调用
         2> initialize是通过objc_msgSend调用
         
         2.调用时刻
         1> load是runtime加载类、分类的时候调用（每个类、分类的+load，在程序运行过程中只调用一次）
         2> initialize是类第一次接收到消息的时候调用，每一个类只会initialize一次（父类的initialize方法可能会被调用多次）
         
         load、initialize的调用顺序？
         1.load
           1> 先调用父类的load
             a) 先编译的类，优先调用load
           2> 后调用子类的load
             a) 先编译的类，优先调用load
           3> 再调用分类的load
             a) 先编译的分类，优先调用load
         2.initialize
           1> 先初始化父类
           2> 再初始化子类（可能最终调用的是父类的initialize方法）
         */
    }
    return 0;
}
