//
//  MJPerson+Test1.m
//  Interview01-load
//
//  Created by MJ Lee on 2018/5/5.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson+Test1.h"

@implementation MJPerson (Test1)

+ (void)load
{
    NSLog(@"MJPerson (Test1) +load");
}

+ (void)test
{
    NSLog(@"MJPerson (Test1) +test");
}

@end
