//
//  MJStudent+Test1.m
//  Interview01-load
//
//  Created by MJ Lee on 2018/5/5.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJStudent+Test1.h"

@implementation MJStudent (Test1)

+ (void)load
{
    NSLog(@"MJStudent (Test1) +load");
}
@end
