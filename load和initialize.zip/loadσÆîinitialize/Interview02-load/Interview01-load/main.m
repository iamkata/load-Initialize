//
//  main.m
//  Interview01-load
//
//  Created by MJ Lee on 2018/5/5.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"
#import "MJStudent.h"
#import <objc/runtime.h>

//打印类对象里面所有的方法
void printMethodNamesOfClass(Class cls)
{
    unsigned int count;
    // 获得方法数组
    Method *methodList = class_copyMethodList(cls, &count);
    
    // 存储方法名
    NSMutableString *methodNames = [NSMutableString string];
    
    // 遍历所有的方法
    for (int i = 0; i < count; i++) {
        // 获得方法
        Method method = methodList[i];
        // 获得方法名
        NSString *methodName = NSStringFromSelector(method_getName(method));
        // 拼接方法名
        [methodNames appendString:methodName];
        [methodNames appendString:@", "];
    }
    
    // 释放
    free(methodList);
    
    // 打印方法名
    NSLog(@"%@ %@", cls, methodNames);
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSLog(@"---------------");
        [MJPerson test];
        //[MJStudent load];
        //如果调用MJStudent的load方法,因为MJStudent中没有load方法,会发现也会调用成功MJPerson (Test2) +load
        //为什么会调用MJPerson (Test2) +load呢?
        //如果你主动调用就是消息机,就根据消息机制的那一套流程,最后会调用后加载的MJPerson (Test2) +load方法
//        objc_msgSend([MJStudent class], @selector(load));
        // isa
        // superclass
        //所以打印结果为:MJPerson (Test2) +load
        
        //如果什么都不写
        //运行打印发现他们各自调用自己的load,并没有像test方法一样调用分类的test方法,为什么呢?
        /*
         2019-04-12 09:45:39.972708+0800 Interview01-load[18294:4160953] MJPerson +load
         2019-04-12 09:45:39.972719+0800 Interview01-load[18294:4160953] MJPerson (Test1) +load
         2019-04-12 09:45:39.972731+0800 Interview01-load[18294:4160953] MJPerson (Test2) +load
         */
 
        //打印MJPerson所有的方法
//        printMethodNamesOfClass(object_getClass([MJPerson class]));
        //打印结果为:MJPerson load, test, load, test, load, test,
        //可以发现所有分类的方法都被加载MJPerson中,但是为什么都调用的是自己的呢?
        
        /*
         +load方法会在runtime加载类、分类时调用,不管你用还是不用,都会被加到内存调用,有几个类和分类就调用几次
         每个类、分类的+load，在程序运行过程中只调用一次
         */

        /*
         +load方法调用顺序
         1.先调用父类的+load
         2.再调用子类的+load
         不同的类按照编译先后顺序调用（先编译，先调用）
         
         3..再调用分类的+load
         不同的类的分类按照编译先后顺序调用（先编译，先调用）
         */
        //总结:分类中+load方法是通过内存地址直接调用,不是发送消息.分类中其他方法是发送消息所以是先调用分类,而且是后编译的先调用,比如:[MJPerson test]) ->因为后编译的放在了数组的前面
    }
    return 0;
}
